const headers = document.getElementsByClassName("header"),
contents = document.getElementsByClassName("content");
icons = document.getElementsByClassName("icon");
for (let i = 0; i < headers.length; i++) {
    headers[i].addEventListener("click", () => {
        contents[i].style.display = contents[i].style.display == "block" ? "none" : "block";
        icons[i].innerHTML = contents[i].style.display == "block" ? `<img src="./img/arrow2.svg" alt="">` : `<img src="./img/arrow.svg" alt="">`;
    });
}
// contents[i].style.display = contents[i].style.display == "block" ? "none" : "block";

let btn=document.querySelectorAll(".btn button")
let item=document.querySelectorAll(".Gallery .item")
console.log(btn[0])
btn[0].addEventListener("click", e => {
    btn[0].classList.toggle('ccc')
    item[1].classList.toggle('none')
    item[2].classList.toggle('none')
    item[3].classList.toggle('none')
    item[5].classList.toggle('none')
})

btn[1].addEventListener("click", e => {
    btn[0].classList.toggle('ccc')
    item[1].classList.toggle('none')
    item[2].classList.toggle('none')
    item[3].classList.toggle('none')
    item[5].classList.toggle('none')
    btn[1].classList.toggle('ccc')
    item[0].classList.toggle('none')
    item[1].classList.toggle('none')
    item[3].classList.toggle('none')
    item[4].classList.toggle('none')
    item[5].classList.toggle('none')
})

btn[2].addEventListener("click", e => {
    btn[1].classList.toggle('ccc')
    item[0].classList.toggle('none')
    item[1].classList.toggle('none')
    item[3].classList.toggle('none')
    item[4].classList.toggle('none')
    item[5].classList.toggle('none')
    btn[2].classList.toggle('ccc')
    item[0].classList.toggle('none')
    item[2].classList.toggle('none')
    item[4].classList.toggle('none')
})


console.log(item)
let garden=document.querySelectorAll(".Garden")
console.log(garden)

let elm = document.querySelectorAll('.banner_indicator-elm');
elm.forEach(elml => console.log(elml))
elm.forEach(ind =>{
    ind.addEventListener('click', function(){
        console.log(ind.innerHTML)
    })
})