const headers = document.getElementsByClassName("header"),
contents = document.getElementsByClassName("content");
icons = document.getElementsByClassName("icon");
for (let i = 0; i < headers.length; i++) {
    headers[i].addEventListener("click", () => {
        contents[i].style.display = contents[i].style.display == "block" ? "none" : "block";
        icons[i].innerHTML = contents[i].style.display == "block" ? `<img src="./img/arrow2.svg" alt="">` : `<img src="./img/arrow.svg" alt="">`;
    });
}
contents[i].style.display = contents[i].style.display == "block" ? "none" : "block";
